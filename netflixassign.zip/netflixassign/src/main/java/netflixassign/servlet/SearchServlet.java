package netflixassign.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import netflixassign.connection.DbCon;
import netflixassign.dao.ProductDao;
import netflixassign.dao.UserDao;
import netflixassign.model.*;

@WebServlet("/SearchServlet")
public class SearchServlet extends HttpServlet {
 
    protected void doPost(HttpServletRequest request,HttpServletResponse response) 
    		throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		        		try (PrintWriter out = response.getWriter()) {    
		        	 //       String Search = (String) request.getAttribute("Search");
		        			String Search = "Vikram";
		        	        ProductDao pd = new ProductDao(DbCon.getConnection());
		        	        Connection conn = java.sql.DriverManager.getConnection("jdbc:mysql://localhost:3306/netflixwebapp", "root", "Varshini.2013");
		        	        Statement stmt = conn.createStatement();
		     			if (Search != null) {
		        			String query = "SELECT * FROM netflixwebapp.products WHERE ";
							query = query + "Name LIKE '%" + Search + "%'";
			                ResultSet rs = stmt.executeQuery(query); 
			                List<Product> book = new ArrayList<>();
			                        while (rs.next()) {
			                        	Product row = new Product();
			                            row.setId(rs.getInt("id"));
			                            row.setName(rs.getString("name"));
			                            row.setCategory(rs.getString("category"));
			                            row.setPrice(rs.getDouble("price"));
			                            row.setImage(rs.getString("image"));

			                            book.add(row);
			                }
			                request.setAttribute("SearchResults", book);     
		        			response.sendRedirect("search.jsp");
		        			} 
		     			else {
		        				out.println("there is no such content");
		        			}
		
		        		} catch (ClassNotFoundException|SQLException e) {
		        			e.printStackTrace();
		        		} 
		
		        	}
         
    }

